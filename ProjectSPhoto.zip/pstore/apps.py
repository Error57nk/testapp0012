from django.apps import AppConfig


class PstoreConfig(AppConfig):
    name = 'pstore'
