from django.contrib import admin
from . models import *
# Register your models here.


admin.site.register(Category)
admin.site.register(PhotoStoreModel)
admin.site.register(OrderFormModel)
admin.site.register(FormCust1Model)
